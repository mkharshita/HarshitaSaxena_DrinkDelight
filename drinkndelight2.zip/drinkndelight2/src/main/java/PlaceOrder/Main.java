package PlaceOrder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Main 
{
	public static void main(String args[])
	{
	System.out.println("Press 1 for Track Order");
	System.out.println("Press 2 for Update Stock");
	System.out.println("Press 3 for Place Order");
	System.out.println("Press 4 for Display Order Details");
	System.out.println("Press 5 for Enter New Supplier's Details");
	System.out.println("Press 6 for Enter New Distributer's Details");
	Scanner sc=new Scanner(System.in);
	//file();
	int n =sc.nextInt();
	choice(n);

	}
	public static void  choice(int n)
	{
	switch(n)
	{
	case 1:new TrackOrderView().choice();
	break;
	case 3: new PlaceOrderView().choice();
	break;
	case 4: new DisplayOrderView().choice();
	break;
	}

	}
	public static void file()
	{
	ArrayList <RawMaterialOrderModel> arr=new ArrayList();
	RawMaterialOrderModel rm=null;
	try {
	FileOutputStream fos = new FileOutputStream(new File("C:\\new\\c.txt"));
	ObjectOutputStream oos = new ObjectOutputStream(fos);
	oos.writeObject(arr);
	oos.close();
	fos.close();
	} catch (Exception e) {
	e.printStackTrace();
	}
	}
}
