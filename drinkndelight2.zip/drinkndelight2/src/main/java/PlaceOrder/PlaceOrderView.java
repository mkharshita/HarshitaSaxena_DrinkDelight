package PlaceOrder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class PlaceOrderView 
{
	Date deliveryDate;
	Date orderDate;
	Scanner sc=new Scanner (System.in);
	public void choice( )
	{
	System.out.println("Press 1 for Product Order");
	System.out.println("Press 2 for Raw Material Order");

	int n=sc.nextInt();
	sc.nextLine();
	switch(n)
	{
	case 1: productEntries();
	break;
	case 2: rawMaterialEntries();
	break;
	default : System.out.println("Wrong Input");
	}


	}
	public void productEntries()
	{
	System.out.println("Enter the orderId");
	String orderId=sc.nextLine();
	System.out.println("Enter the Product Id");
	String productId=sc.nextLine();
	System.out.println("Enter the Distributor Id");
	String distributorId=sc.nextLine();
	System.out.println("Enter the Order Date");
	String s1=sc.nextLine();
	System.out.println("Enter the Delivery Date");
	String s2=sc.nextLine();
	Date deliveryDate;
	Date orderDate;


	try
	{
	deliveryDate=new SimpleDateFormat("dd/MM/yyyy").parse(s1);
	orderDate=new SimpleDateFormat("dd/MM/yyyy").parse(s2);
	}
	catch(Exception e)
	{
	System.out.println("Wrong Input Date");
	}
	System.out.println("Enter the Quantity");
	double quantity=sc.nextInt();
	System.out.println("Enter the Price");
	double price=sc.nextInt();
	sc.nextLine();
	//new PlaceOrderController.product(orderId,productId,distributorId,orderDate,deliveryDate,quantity,price);


	}
	public void rawMaterialEntries()
	{
	System.out.println("Enter the orderId");
	String orderId=sc.nextLine();
	System.out.println("Enter the Raw Material Id");
	String rawMaterialId=sc.nextLine();
	System.out.println("Enter the Supplier Id");
	String supplierId=sc.nextLine();
	System.out.println("Enter the Order Date");
	String s1=sc.nextLine();
	System.out.println("Enter the Delivery Date");
	String s2=sc.nextLine();



	try
	{
	deliveryDate=new SimpleDateFormat("dd/MM/yyyy").parse(s2);
	orderDate=new SimpleDateFormat("dd/MM/yyyy").parse(s1);
	}
	catch(Exception e)
	{
	System.out.println("Wrong Input Date");
	}
	System.out.println("Enter the Quantity");
	double quantity=sc.nextDouble();
	System.out.println("Enter the Price");
	double price=sc.nextDouble();
	new PlaceOrderController().rawMaterial(orderId,rawMaterialId,supplierId,orderDate,deliveryDate,quantity,price);


	}

}
