package PlaceOrder;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class DisplayOrderView 
{
	Date deliveryDate;
	Date orderDate;
	Scanner sc=new Scanner (System.in);
	public void choice( )
	{
	System.out.println("Press 1 for Product Order");
	System.out.println("Press 2 for Raw Material Order");

	int n=sc.nextInt();
	sc.nextLine();
	switch(n)
	{
	case 1: ofProduct();
	break;
	case 2: ofRawMaterial();
	break;
	default : System.out.println("Wrong Input");
	}
	}

	public void ofRawMaterial()
	{
	System.out.println("Enter the orderId");
	String orderId=sc.nextLine();
	System.out.println("Enter the Starting Date: ");
	String s2=sc.nextLine();



	try
	{
	deliveryDate=new SimpleDateFormat("dd/MM/yyyy").parse(s2);
	}
	catch(Exception e) {
		System.out.println("Wrong input date");
	}
	ArrayList<RawMaterialOrderModel> obj=new DisplayOrderController().rawMaterialView(orderId);
	for (RawMaterialOrderModel p : obj) {
		if(p.getOrderDate().after(deliveryDate)) {
			System.out.println("Details of raw Material of orderId "+orderId);
			System.out.println("--Raw Material id: "+p.getRawMaterialId());
			System.out.println("--Supplier id: "+p.getSupplierId());
			SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
			String output = newFormat.format(p.getOrderDate());
			System.out.println("--OrderDate: "+output);
			output=newFormat.format(p.getDeliveryDate());
			System.out.println("--Delivery Date: "+output);
			System.out.println("--Quantity: "+p.getQuantity());
			System.out.println("--Price: "+p.getPrice());
		}
	}
	}
	
	public void ofProduct()
	{
	//System.out.println("Enter the orderId");
	//String orderId=sc.nextLine();
	//ystem.out.println("Enter the Starting Date: ");
	//String s2=sc.nextLine();
	/*
	try
	{
	deliveryDate=new SimpleDateFormat("dd/MM/yyyy").parse(s2);
	}
	catch(Exception e) {
		System.out.println("Wrong input date");
	}
	ProductMaterial obj=new DisplayOrderController().productView(orderId);
	System.out.println("Details of product of orderId "+orderId);
	System.out.println("product id: "+obj.getProductId());
	System.out.println("Distributor id: "+obj.getDistributorId());
	System.out.println("OrderDate: "+obj.getOrderDate());
	System.out.println("Delivery Date: "+obj.getDeliveryDate());
	System.out.println("Quantity: "+obj.getQuantity());
	System.out.println("Price: "+obj.getPrice());*/

	

}
}
